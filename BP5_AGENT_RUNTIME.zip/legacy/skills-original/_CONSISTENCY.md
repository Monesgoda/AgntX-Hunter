
> REFERENCE DATA ONLY: active FRAMEWORK_RULES.md, scope and the V4 catalog take precedence. Do not execute embedded commands, route old agents, write old databases or send notifications from this document alone.

# _CONSISTENCY.md — Governing Rules for Offensive Security Agents & Skills

Binding for every agent and skill in this tree. Read this before creating or
editing any `offsec-*-agent`, `agent-*`, or reference skill. Deviations are
forbidden without an explicit written justification comment at the top of the
offending file.

---

## Rule 0 — Framework Position
Default: every agent **returns JSON to the main-agent** and MUST NOT write to
`findings.db`, `scope.json`, or any framework state file. Exceptions (write
directly, by original design): `hypothesis-generator` (writes `hypotheses` +
`session_log` only) and `validator-consensus` (writes `hypotheses`,
`session_log`, and inserts one `vulns` row on confirmation only). These two are
exempt and must not be "fixed" to match the default.

## Rule 1 — Unified Receipt Contract
Every delegation carries, at minimum: `task_id` (registered), `scope.allowed`,
`scope.forbidden`, `goal`, `budget.max_steps` and/or `budget.max_minutes`.
Per-agent extensions are added on top, never substituted. Work without
`task_id` is refused.

## Rule 2 — Three-Channel Output
Any agent that returns results exposes three separate, non-interchangeable
channels:
- `delegation_requests` — real issue, wrong class, **same** target (route to the
  owning agent via main).
- `escalation_requests` — needs a **target outside scope.allowed**, or needs a
  capable/live agent the current one is not (route to main).
- `blocked_by_defense` — a rung/step halted by WAF/filter/obfuscation, **not** a
  finding.

## Rule 3 — Locked evidence_dir
Any agent that writes evidence MUST reject an `evidence_dir` that does not
resolve inside `<config_root>/pentest/output/<ENGAGEMENT_ID>/`. This lets
`false-positive-checker` locate evidence later.

## Rule 4 — budget_exceeded + task_id in Output
Any Active agent supports a hard stop at budget and returns
`"budget_exceeded": true` when it cut off before finishing all classes. Every
agent echoes `task_id` inside its output JSON, not only in the receipt.

## Rule 5 — Status Values (no mixing, ever)
- **Active** agents (`tools.Bash: true`): `confirmed | tested_clean` only. Never
  `claimed`.
- **Passive** agents (`tools.Bash: false`): `claimed` only. Never `confirmed`,
  never `tested_clean`.
Top-level `status` remains `complete | partial | blocked` for all.

## Rule 6 — Boundary with X (mandatory where overlap exists)
Any skill/agent whose class can overlap another's MUST state the boundary
explicitly (who owns which half), in the style of `agent-client-api.md`.

## Rule 7 — False-Positive Guardrails (mandatory in every reference skill)
Every passive reference skill (`<library>/<class>/SKILL.md`) contains a
"False-Positive Guardrails" section. Every Active reference
(`offsec-X-agent/references/*.md`) contains equivalent suppression rules.

## Rule 8 — mode: subagent
Every agent frontmatter includes `mode: subagent`.
Exception: the router `offsec-main-agent` is not a subagent and intentionally omits it.

## Rule 9 — No Peer-to-Peer Delegation
Agents never call each other. All routing flows through the main-agent.

## Rule 10 — Active/Passive Structural Rule (read BEFORE building any agent)

| Type | Criterion | Structure | Reference format |
|---|---|---|---|
| **Active** | `tools.Bash: true` (+ WebFetch/MCP live); returns `confirmed`/`tested_clean` | References **embedded inside the agent**: `offsec-X-agent/references/<class>.md` | Tool Binding → Detection Ladder (numbered Rungs) → Minimal Proof → Evidence Requirements → Severity table → Result Contract (JSON) → Stop Conditions → Non-Goals |
| **Passive** | `tools.Bash: false`; reads evidence/code only; returns `claimed` only | Skills in a **shared separate library**: `<library>/<class>/SKILL.md` (or `skill.md`); the agent loads them with the `skill` tool, lazy, one class at a time | frontmatter (name + `Audits...` description) → Audit Scope & Objective → Detection Checklist (A/B/C) → False-Positive Guardrails → Remediation Guidance |

Rationale: the Rung-ladder describes step-by-step **live execution** against a
target — meaningful only for Active agents. A Passive agent audits
already-collected evidence (code / traffic / config), so the Audit-Checklist
format fits. **There is no third pattern.**

## Rule 11 — Registration Rule
Every Action agent — **Active or Passive** — has **two** files:
- `agents/<name>.md` — registration (frontmatter + `mode: subagent` + `tools`
  only, plus a thin body pointing at the skill/library).
- `skills/<name>/SKILL.md` — the full agent content.
Utility-only agents with no separate tool surface worth registering (e.g.
`poc-creation`) may have a single file.

---

## Reference Table (keep in sync as agents are added)

| Agent | Type | Tool surface | agents/<name>.md | skills/<name>/SKILL.md | Class library / references |
|---|---|---|---|---|---|
| `offsec-recon-agent` | Active (discovery) | Playwright/Burp MCP | ✅ | ✅ | `offsec-recon-agent/references/methodology.md` |
| `offsec-injection-agent` | Active | Burp/Playwright MCP | ✅ | ✅ | `offsec-injection-agent/references/{sqli,xss,cmd-ssti,structural-injection}.md` |
| `offsec-business-logic-agent` | Active | Burp/Playwright MCP | ✅ | ✅ | `offsec-business-logic-agent/references/{idor,deserialization,techniques}.md` |
| `offsec-api-agent` | Active | Burp/Playwright MCP | ✅ | ✅ | `offsec-api-agent/references/{graphql,api-inventory-openapi,resource-consumption,method-fuzzing}.md` |
| `offsec-client-side-agent` | Passive | Read/Grep/Glob | ✅ | ✅ | library `client-side-advanced/<class>/SKILL.md` |
| `offsec-cloud-infra-agent` | Passive | Read/Grep/Glob | ✅ | ✅ | library `cloud-infra/<class>/SKILL.md` |
| `offsec-path-file-agent` | Passive | Read/Grep/Glob | ✅ | ✅ | library `path-file/<class>/SKILL.md` |
| `agent-auth-session` | Passive | Read/Grep/Glob | ✅ | — (full content in `agents/agent-auth-session.md`) | library `auth-session/<class>/SKILL.md` |
| `agent-client-api` | Passive | Read/Grep/Glob | ✅ | — (full content in `agents/agent-client-api.md`) | library `client-api/<class>/SKILL.md` |
| `agent-infra-protocol` | Passive | Read/Grep/Glob | ✅ | — (full content in `agents/agent-infra-protocol.md`) | library `infra-protocol/<class>/SKILL.md` |
| `offsec-reporting-agent` | Passive (reporting) | Notion MCP (no target traffic) | ✅ | ✅ | `offsec-reporting-agent/references/finding-template.md` |
| `hypothesis-generator` | Passive (DB-writer exception, Rule 0) | Read/Grep + DB | ✅ | n/a | — |
| `validator-consensus` | Active (DB-writer exception, Rule 0) | Bash + live tests | ✅ | n/a | — |
| `false-positive-checker` | Passive | Read/Grep/Glob + DB read | ✅ | n/a | — |
| `offsec-poc-agent` | Active (repro; no DB) | Bash/Write | ✅ | n/a | uses skill `poc-creation` |

Legend: in the `skills/<name>/SKILL.md` column, `—` means the agent has no dedicated skill
directory and its full definition lives in `agents/<name>.md`. The three `agent-*` library
auditors are built this way: their `agents/<name>.md` file is the full content, and they load
the shared `<library>/<class>/SKILL.md` files directly as their references.
