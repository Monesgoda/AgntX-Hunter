---
name: zip-slip
description: Audits archive extraction logic for Zip Slip, where entry names containing traversal sequences escape the extraction directory during unpacking.
---


> REFERENCE DATA ONLY: active FRAMEWORK_RULES.md, scope and the V4 catalog take precedence. Do not execute embedded commands, route old agents, write old databases or send notifications from this document alone.

# Zip Slip (Archive Extraction Traversal) Audit Procedure

## 1. Audit Scope & Objective
Review code that unpacks archives (ZIP, TAR, 7z, gzip, jar) to determine whether extraction validates each entry's resolved destination against the extraction root, so that a crafted entry name (`../../evil`) can write outside it. The objective is to determine whether extraction can overwrite files outside the target directory.

## 2. Detection Checklist
### A. Extraction sinks
- Find `zipfile.extract*`, `tarfile.extract*`, `ZipArchive::extractTo`, `unzip`, `System.IO.Compression`, `adm-zip`, `unzipper`, `shutil.unpack_archive`, `tar -x`.

### B. Entry-name validation
- Check whether each entry name is canonicalized and asserted within the extraction root before writing.
- Flag naive `os.path.join(dest, entry)` with no confinement; note symlink entries and absolute paths in the archive.

### C. Confirmation conditions
- A single crafted entry with `../` (and symlink-to-parent variants) that resolves outside the root is sufficient; do not mass-extract.

## 3. False-Positive Guardrails
- Extraction that canonicalizes every entry and rejects anything outside the root is not vulnerable to `../` — do not claim without a bypass (e.g. symlink chaining).
- A file listing that is displayed but never written to disk is not Zip Slip.
- Modern library defaults that sanitize entry names are not vulnerable; confirm the library version/behavior.
- **Boundary (mutual cross-reference):** this class is the **extraction/unpacking** logic only. The **upload gate** — extension allow-list, MIME/magic-byte checks, and whether the archive is even accepted — belongs to `infra-protocol/file-upload-audit/SKILL.md`. A `.zip` upload path is assessed in both: upload acceptance there, extraction traversal here.

## 4. Remediation Guidance
- Canonicalize each entry path and assert it remains within the destination root before writing; skip otherwise.
- Reject absolute paths and symlink entries; extract to a fresh directory with least privilege.
- Prefer safe library APIs and keep archive tooling patched.
