---
name: path-traversal
description: Audits user-supplied file paths for directory traversal that allows reading or writing files outside the intended directory.
---


> REFERENCE DATA ONLY: active FRAMEWORK_RULES.md, scope and the V4 catalog take precedence. Do not execute embedded commands, route old agents, write old databases or send notifications from this document alone.

# Path Traversal Audit Procedure

## 1. Audit Scope & Objective
Review code, configuration, and captured requests where a user-controlled path/filename is joined to a base directory, to determine whether `../` sequences (or encoded variants) let an attacker read or write files outside the intended root. The objective is to determine whether path confinement can be escaped.

## 2. Detection Checklist
### A. Sink identification
- Find filesystem operations taking a user-supplied name: `open`, `readFile`, `send_file`, `FileResponse`, `os.path.join`, `path.join`, `Paths.get`, `new File(...)`, `include`, template loaders.

### B. Confinement logic
- Verify whether the resolved path is canonicalized (`realpath`, `canonicalize`, `filepath.Clean`) and asserted to remain under the base directory.
- Look for naive concatenation (`base + user`), blacklist-only checks, or checks done before resolution.

### C. Encoding and filter bypass
- Test `../`, `..%2f`, `%2e%2e/`, double-encoding, `....//`, backslashes, absolute paths, null byte (`%00`) on legacy stacks, and OS-specific separators.
- On Windows, also test `..\`, UNC paths (`\\server\share\`), drive-relative/absolute (`C:\`, `C:file`), and NTFS alternate data streams (`file.txt::$DATA`) that defeat naive `../`-only filters.
- Consider TOCTOU: a canonicalize-then-open race where the path is validated via `realpath` but the file is swapped (symlink) between the check and the open.

## 3. False-Positive Guardrails
- A parameter that only selects from a fixed enum/map (no filesystem concatenation) is not traversal.
- A path that is canonicalized and prefix-checked against the base is not vulnerable to `../` — do not claim without an actual bypass.
- A queue report must show a concrete escaped path or disclosed file, not just the presence of `../` in a request.
- Boundary: archive extraction is `path-file/zip-slip`; upload extension/MIME gating is `infra-protocol/file-upload-audit`; the traversal itself is this class.

## 4. Remediation Guidance
- Resolve to a canonical absolute path and verify it is within the allowed base before any filesystem operation.
- Use an allow-list of filenames/IDs and map them server-side to paths; never concatenate raw input.
- Reject path separators and encoded/Unicode variants; run with least-privilege filesystem access.
