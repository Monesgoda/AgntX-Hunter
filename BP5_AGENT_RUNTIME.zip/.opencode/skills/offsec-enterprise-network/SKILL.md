---
name: offsec-enterprise-network
description: Scope-aware network inventory and posture review, with Nmap result interpretation.
---
# Network Security
Use Nmap service inventory provided by Recon, plus permitted DNS, TLS and configuration records. Correlate ports, protocols, version strings, network segments, routing, service access controls and exposed administration interfaces. Compare observed configuration against expected policy. Do not infer vulnerability from the mere existence of a service. Log traffic/noise expectations and host boundaries. Network capture or interception requires separate authorization. Coordinate with Infrastructure, API or Access/Auth where findings overlap.

## Network evidence and service triage
1. Inputs: authorized subnet or exact hosts, allowed port boundaries, Nmap XML/JSONL, passive DNS/TLS data, accepted inventory, scan timestamps.
2. Separate raw discovery from attack-surface hypotheses: protocol reachability, exposed management services, unsupported services, weak transport configurations, unexpected route/control-plane exposure.
3. Attribute ownership correctly: domain login and Kerberos symptoms to AD skill; web services to API/Infra; cloud control planes to Cloud skill; cluster APIs to Container skill.
4. Determine whether a service is internal-only, internet-facing, or protected by trust boundaries. Do not assume remote reachability from a local scan result.
5. For TLS/services use approved configuration checks, version and certificate inspection; compare with hardened reference where available. Avoid broad attacks on public infrastructure absent approval.
6. Evidence: raw tool output, host and port, protocol, timestamp, chosen observation scope, service banner confidence, and what the evidence does not establish.
7. Validation: compare against known-good expected boundary and use minimum traffic. State hypotheses and assign to the relevant specialist for impact testing; a `state=open` observation never becomes `confirmed` by itself.
