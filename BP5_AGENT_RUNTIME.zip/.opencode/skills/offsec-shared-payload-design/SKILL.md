---
name: offsec-shared-payload-design
description: Build safe, bounded test cases and differential controls for authorized vulnerability hypotheses; no general-purpose attack launcher.
---
# Test-case / Payload Design — shared reference

Keep the test harmless and specific to a registered scoped hypothesis. State the input point, expected safe behavior, possible trust boundary failure, and a benign control. Prefer non-executing markers, synthetic accounts, local canaries and disposable fixtures. Preserve status/length/time/signature and stop on blocks or side effects. Do not create bulk payload lists for external targets, credential attacks, stealth or bypass tooling.

Return test input as a proposal requiring specialist selection; only real recorded observations count as evidence.
