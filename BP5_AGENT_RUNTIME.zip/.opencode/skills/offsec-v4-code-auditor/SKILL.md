---
name: offsec-v4-code-auditor
description: Source-backed vulnerability hypothesis discovery and bounded handoff for a user-supplied, authorized repository.
---
# Code Audit — scope-bound, evidence-first

## Preconditions
Read-only local source supplied by the user and explicit assessment permission. Mapped, explicitly scoped endpoints are required only for a routable runtime handoff; source without a grounded endpoint can still receive a local review note. Do not clone arbitrary repositories or execute CI/install scripts without separate approval.

## Workflow
1. Inventory language/framework, entry points, controllers/routes, data models, auth boundaries and external integrations.
2. Trace user-controlled data across authorization and validation boundaries; note guards and mitigations as well as missing controls.
3. Record file path + line span + relevant precondition + proposed safe differential test. Prefer no runtime inference when routes are unknown.
4. Map to one family: access-auth, injection, client-side, file-path, request-forgery, business-logic, infra, api or llm-security.
5. When the endpoint is explicitly in scope and present in the source, send an **unverified** lead via `hunter-lead --source code-audit`.
6. Return negative findings, unknowns, and code references; never mark static suspicion as proven.

## Handoff record
`repository_reference`, `commit/hash`, `file`, `line_range`, `endpoint`, `method`, `family`, `hypothesis`, `evidence_refs`, `assumptions`, `suggested_low_impact_control`, `confidence`.
No secrets, third-party records or executable payloads in the summary.

## Restored static analysis library
Read `pentest/references/code-audit/code-vuln-core/SKILL.md`, then only the
matching family adapter in that directory. The active catalog owns routing;
SSRF belongs to request-forgery, mass assignment to access-auth. The adapters
produce static hypotheses only and do not replace the central lead gateway.
