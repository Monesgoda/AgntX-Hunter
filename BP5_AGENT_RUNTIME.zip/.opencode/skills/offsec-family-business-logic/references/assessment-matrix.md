# Business-Logic — bounded assessment matrix

These are **method selection cues**, not exploit payloads or proof. Only test authorized targets; store real comparative observations and independently reproduce.

| Subtype | Audit target | Evidence required | False-positive guard |
|---|---|---|---|
| Race Conditions | Atomic state updates, quota controls | Limited concurrency on disposable accounts yields duplicate state change | Latency spikes alone are insufficient |
| Functionality Confusion | Workflow state transition contract | Test-only unexpected transition across allowed steps causes forbidden final state | Skipped UI pages alone are not server bypass |
| Logic Privilege Escalation | Role transitions and business privileges | Low-privilege test principal obtains restricted operation through application logic | Frontend role labels alone are not proof |
| Plan / Feature Abuse | Entitlement expiry, quota, offline enforcement | Disposable test plan gains paid capability without entitlement | Plan UI rendering does not prove backend enforcement |
| Price / Parameter Manipulation | Server-side total recomputation | Disposable cart mutation creates incorrect server-accepted total | Client display showing wrong value alone is not financial impact |

## Evidence checklist
- Capture known authorized scope, test account role, endpoint, method, consent and environmental constraints.
- Record baseline and at least two independent observations with status, response length, timing and relevant normalized content fingerprint.
- Classify `blocked`, `not_reproduced`, `inconclusive` explicitly. Avoid claiming a discovered version/header/URL proves a vulnerability.
- Attach redacted raw evidence and reproduce with a separate execution before POC verification.
- Never use public exploitation or bypass filters merely to make a proof succeed.
