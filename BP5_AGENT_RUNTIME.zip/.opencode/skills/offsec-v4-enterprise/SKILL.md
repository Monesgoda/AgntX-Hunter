---
name: offsec-v4-enterprise
description: Cross-domain enterprise assessment using specialized network, AD, cloud and container reference skills.
---
# Enterprise Security
Receive only engagement-scoped targets, service observations or configuration artifacts. Use the family reference matching the technology: `offsec-enterprise-network`, `offsec-enterprise-ad`, `offsec-enterprise-cloud`, or `offsec-enterprise-container`.
Check prerequisites/authorization, choose proportional observation and validation, and preserve actual command/output evidence and SHA-256. A discovered port or missing header is not a confirmed vulnerability. Send overlapping web/API/authorization findings to the corresponding specialists through Main's shared handoff, without waiting for the Enterprise review to finish. For non-HTTP assets, do not claim that a generic asset-observation write exists: `hunter-observations --engagement <ENGAGEMENT>` is read-only. For supported Nmap services, use `nmap-service-lead --engagement <ENGAGEMENT> --host <HOST> --port <PORT> --protocol <tcp|udp> --service <SERVICE> --requested-by enterprise --target-agent enterprise`. For other non-web evidence, keep the evidence reference and limitation in the assigned task/engagement response for Main; do not invent a SQLite persistence command or fabricate an HTTP URL. Invasive changes to networks, identities, credentials or cluster infrastructure need separate task-level approval and blast-radius review.
Output: engagement_id, assets, observed services/config, hypotheses, test status, raw evidence, proposed owner agent, limitations.

## Enterprise technical workflow
**Input contract:** engagement_id and scope snapshot, affected hosts/ranges/cloud accounts or cluster namespaces, authorization level, source observations, allowed methods, evidence references, elapsed-time and request budgets.
**Analysis:** correlate Nmap service fingerprints with directory roles, server configurations, cloud accounts, identity providers and Kubernetes metadata. Do not treat a version string as a confirmed CVE; collect evidence about the exact affected version and reachable control boundary.
**Ownership:** Enterprise owns non-web network/identity/cluster observations and can immediately route web/API issues to other specialists. A CTF target can be handled jointly with the CTF Solver under the same engagement. The primary routes without requiring an earlier specialist failure.
**Evidence:** include affected asset identifiers, precise permission context, actual observed output and negative controls. Preserve raw outputs with hash and source timestamps; minimize secrets and unrelated-user content.
**Reporting:** state tested versus untested hypotheses, blast-radius assumptions, impact proof, remediation direction, and detection clues. Escalate security findings for independent POC review when measurable impact exists; do not assert exploitability based on public vendor version lists alone.
**Continuity:** Enterprise does not wait for every subskill to finish before using another; use the shared queue to interleave authorized tasks under global rate/host concurrency limits.
