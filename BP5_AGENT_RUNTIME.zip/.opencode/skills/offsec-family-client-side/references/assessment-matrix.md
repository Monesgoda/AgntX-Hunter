# Client-Side — bounded assessment matrix

These are **method selection cues**, not exploit payloads or proof. Only test authorized targets; store real comparative observations and independently reproduce.

| Subtype | Audit target | Evidence required | False-positive guard |
|---|---|---|---|
| Reflected / Stored XSS | Rendering context, sink and trust boundary | Safe inert marker followed by confirmed contextual browser effect using disposable state | Reflected input alone is not script execution |
| DOM XSS | Client-side source-to-sink dataflow | Independent browser session reproduces unsafe processing | Dangerous sink in minified code is only a lead |
| Blind XSS | Asynchronous rendering in approved test account | Pre-authorized benign callback shows marker was processed | Unattributed callbacks are inconclusive |
| Swagger UI XSS | UI version and rendered spec surface | Browser-local test fixture reproduces the unsafe rendering | Presence of Swagger UI is not vulnerability |
| SVG Upload XSS | Upload handling and image sandbox policy | Disposable SVG under explicitly allowed file-upload tests confirms script context | Rendering as inert image is not script execution |
| DOM Clobbering | DOM named property handling | Controlled page fixture changes a security-relevant property | A duplicate ID alone is not exploitable |
| Prototype Pollution | Object merge/update path | Benign property is affected across unexpected objects | Library version or __proto__ substring alone is insufficient |
| postMessage | Sender origin validation and downstream sensitive action | Approved origin and test frame demonstrate unauthorized message acceptance | Receiving a message alone is expected behavior |
| Cookie Tossing / SameSite | Cookie scope and credential flow | Scoped browser test shows meaningful session/security control impact | Cookie attributes alone rarely prove auth bypass |
| CSP Bypass | Policy and browser sink behavior | Explicitly approved non-destructive browser reproduction shows policy not enforcing expected boundary | Header omission belongs to infra until actual client-side impact |
| Open Redirect | Allowlisted destination validation | Controlled benign destination redirect verified without following unknown links | Return URL parameter alone is not proof |
| Clickjacking | Frame policy and sensitive UI | Disposable test page can frame a security-relevant action without authorized anti-framing | Absent X-Frame-Options alone is a hygiene lead |

## Evidence checklist
- Capture known authorized scope, test account role, endpoint, method, consent and environmental constraints.
- Record baseline and at least two independent observations with status, response length, timing and relevant normalized content fingerprint.
- Classify `blocked`, `not_reproduced`, `inconclusive` explicitly. Avoid claiming a discovered version/header/URL proves a vulnerability.
- Attach redacted raw evidence and reproduce with a separate execution before POC verification.
- Never use public exploitation or bypass filters merely to make a proof succeed.
