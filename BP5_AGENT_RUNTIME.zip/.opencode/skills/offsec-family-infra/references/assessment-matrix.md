# Infra — bounded assessment matrix

These are **method selection cues**, not exploit payloads or proof. Only test authorized targets; store real comparative observations and independently reproduce.

| Subtype | Audit target | Evidence required | False-positive guard |
|---|---|---|---|
| WAF Signals | Observed 401/403/429/503 and response fingerprints | Measure behavior and stop on policy blocks; treat as environment state | Do not automatically bypass blocks |
| Subdomain Takeover | DNS ownership and unclaimed service state | Provider-documented verifiable ownership mismatch without registering other parties’ resources | Dangling DNS is a lead until claimability is proven |
| Cloud Storage Misconfig | Bucket/object ACL and signing | Test-owned public object unexpectedly readable with no secret leakage | Bucket hostname existence is not exposure |
| Host Header / HTTP Headers | Reverse proxy trust and generated URLs | Disposable host handling changes trusted security-sensitive server behavior | Host reflection is not automatically poisoning |
| Exposed Redis / Mongo / Elasticsearch / Docker API | Known service bindings and approved architecture | Read-only authenticated metadata on authorized port shows unauthorized exposure | Banner disclosure may be informational only |
| CI/CD / Container / K8s | Secrets and control-plane configuration | Offline configuration violation tied to actual reachable threat boundary | Old config example does not prove live exposure |
| Dependency Confusion / Supply Chain / JS Libraries | Package namespace / provenance / lockfiles | Safe package resolution proof in isolated project | Outdated dependency alone needs vulnerable usage evidence |
| Information Disclosure | Sensitive output in scoped cached evidence | Redacted evidence of actual nonpublic content with impact | Verbose exception is often informational |
| CORS / Security Headers | Allowed origins and credential behavior | Controlled origin/credentials response shows protected data read possible | Wildcard ACAO without credentials is not automatically critical |
| HTTP Request Smuggling | Front-end/back-end parser mismatch | Only approved isolated lab differential with strict low impact and no desync of users | Do not attempt shared-proxy desynchronization in production |
| Web Cache Poisoning / Deception | Cache key, vary controls, authentication boundary | Disposable controlled response is inappropriately cached or replayed | Cache-Control absence alone is not cache poisoning |

## Evidence checklist
- Capture known authorized scope, test account role, endpoint, method, consent and environmental constraints.
- Record baseline and at least two independent observations with status, response length, timing and relevant normalized content fingerprint.
- Classify `blocked`, `not_reproduced`, `inconclusive` explicitly. Avoid claiming a discovered version/header/URL proves a vulnerability.
- Attach redacted raw evidence and reproduce with a separate execution before POC verification.
- Never use public exploitation or bypass filters merely to make a proof succeed.
