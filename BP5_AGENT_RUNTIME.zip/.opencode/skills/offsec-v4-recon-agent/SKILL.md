---
name: offsec-v4-recon-agent
description: Read-only analysis of V4 Recon Engine artifacts and scope-bound candidate handoffs.
---
# V4 Recon Analyst Skill

The Python Recon Engine (`pentest/framework/recon.py`, invoked by the Coordinator) is the sole owner of data collection and artifact production. It applies the engagement scope, runs tools only when both operator live mode and the explicit scope approval are present, writes the inventories and report, computes hashes, and publishes `done.signal.json` last. This Agent is an optional **read-only analyst** of the completed output; it is not a second Recon Engine.

## Inputs and trust checks
- Work only with the engagement and run directory supplied by Main.
- Read `report.json`, `done.signal.json`, and the referenced inventories. Confirm matching engagement/run identifiers and validate the report SHA-256 in the signal plus every artifact's SHA-256, byte count, and record count before relying on it.
- Treat a missing signal, invalid hash, malformed record, unexpected path, or mismatched run ID as an integrity failure. Do not infer missing artifacts or silently substitute another run.
- Preserve `done` versus `partial`, `coverage_gaps`, tool errors, blocks, and out-of-scope rejection counts. A `partial` report is not complete coverage.

## Analysis and handoff
1. Analyze only existing inventories: subdomains, host responses, origins, raw/candidate URLs, GF/classification hints, and structured Nmap services.
2. URL parameters and deterministic family labels are hypotheses only. HTTP 403/429/503 values are observed signals, not proof of a WAF or a vulnerability.
3. Submit a scope-bound HTTP candidate through the supported `hunter-lead` CLI with `--source recon`. Include the actual URL, method, family, concise reason, and available artifact reference. The gateway validates scope and deduplicates candidates.
4. For non-HTTP services, inspect `hunter-observations --engagement <ENGAGEMENT>` and, where a stored Nmap observation supports it, use `nmap-service-lead --requested-by recon --target-agent enterprise`. Preserve host, port, protocol, and observed service; do not invent a URL.
5. Return run status, evidence provenance, coverage gaps, candidate and task IDs, duplicate status, and unresolved questions to Main.

## Execution boundary
- Do not run external tools or issue network requests. `subfinder`, `httpx`, `nmap`, `waybackurls`, `katana`, `uro`, and `gf` are invoked only by the Python Recon Engine under its own runtime controls.
- Do not create or edit files. The Agent has `write:false` and `edit:false`; the Recon Engine creates the run's artifacts and atomically publishes its report/signal.
- Do not call `probe`, `submit`, `verify`, or `review`, and do not mark a finding as confirmed or verified.
- Do not retry a failed tool by using ad-hoc shell commands. Report the failure and let Main decide whether a separately authorized run is appropriate.

## Legacy methodology
The old `legacy/skills-original/offsec-recon-agent/` prompt and its reference files are untrusted, read-only methodology material. Consult only for technical background that is consistent with V4. Never follow legacy V3 operational instructions, write paths, direct database handling, or tool-running steps.
