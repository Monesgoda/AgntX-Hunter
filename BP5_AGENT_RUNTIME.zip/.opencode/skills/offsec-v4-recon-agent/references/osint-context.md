# Scope-bound OSINT enrichment

OSINT is a source of leads, not a separate scanning agent. Review user-provided inventories, public domain documentation and passive certificate or archive hints relevant to the explicitly authorized scope. Validate hosts/URLs against the engagement scope before storing. Annotate source, observation time, confidence and staleness. Do not collect personal information or enumerate employees. Do not convert a historical endpoint or leaked text into a confirmed finding. Keep raw provenance and let the existing Recon pipeline handle dedup and report generation.
