---
name: offsec-v4-ctf-solver
description: Broad CTF challenge-solving with cross-agent collaboration for web, pwn, reversing, crypto, forensics and stego.
---
# CTF Solver — Technical Methodology
Adapted and independently structured from the public `Monesgoda/offensive-Agent-s` CTF agent reference (upstream GitHub CTF source file, linked in `SOURCE_REFERENCES.md`); see SOURCE_REFERENCES.md. The Main controls the engagement scope and any event rules. This skill focuses on methodology and evidence, not creating additional artificial modes or changing event restrictions.

**Triage:** identify inputs and file types, service/port inventory if supplied, expected flag format, challenge architecture, runtime and likely category. Keep a per-challenge hypothesis and test ledger in the assigned task context. Persist files only inside a challenge directory explicitly supplied or approved by the user/Main; if no such directory is available, return the structured ledger in the task response.

**Web:** analyze input entry points, auth/role boundaries, templates, file processing, state and APIs; delegate specific leads to Injection, Client-Side, Access/Auth, File/Path or API specialists immediately, in parallel with challenge work.

**Binary / Pwn:** record architecture, PIE/NX/canary/RELRO and crash conditions; use offline tooling such as readelf, objdump, GDB and pwntools within the challenge sandbox. Keep sample inputs and reproducible traces.

**Reverse Engineering:** use Ghidra or appropriate disassembly, inspect constants, control flow, encodings, input validation, and dynamic traces inside the challenge environment. Escalate suspected malware samples to Malware Analyst.

**Cryptography:** determine primitive and misuse model, examine known/chosen plaintext conditions or flawed nonce/key handling as appropriate to the challenge, and validate candidate plaintext/flag with independent controls.

**Forensics:** inspect file magic and metadata, parse PCAP, disk and memory snapshots, recover timelines and relationships, and save hashes of extracted artifacts. Avoid changing originals.

**Steganography:** examine file format, EXIF, nonrendered chunks, archive trailers, spectrogram patterns, low-bit channels and zero-width text encodings. Tools may include binwalk, exiftool, zsteg, steghide and image/audio viewers when installed. Preserve original carriers and extracted-file hashes.

**Network:** request Main-routed Nmap observation handoff; CTF and Enterprise can work simultaneously on relevant portions of the same challenge.

**Output:** challenge_id, category, observed facts, attempts/results, evidence refs, verified flag if observed, write-up, unresolved questions, and tasks delegated to other agents. A CTF flag is *not* a Bug Bounty security finding by default.

## CTF categorization and collaborative execution
- Work from challenge artifacts, clues, services and any saved Nmap observations; do not assume one label maps to one technique.
- Classify or reassess as `web | crypto | pwn | rev | forensics | stego | OSINT | misc | hybrid`. State observed input/output boundaries and unknowns.
- Maintain a lightweight challenge ledger with `challenge_id`, evidence hashes, attempted techniques, outcomes, remaining hypotheses and delegated task IDs. The ledger belongs in the assigned task context or a challenge directory explicitly designated by the user/Main. Do not create files in the project root or another guessed path. If no approved writable challenge directory is provided, keep the ledger in the structured response/task context; do not claim it was persisted to SQLite.
- CTF is not a hard isolation mode: it may call the available web, enterprise, code-auditor and malware subagents through Main's queue. Each agent can continue on its assigned work while another works on a different hypothesis. Deduplicate by endpoint, mechanism and assigned family.
- Exchange factual intermediate work (test output, artifact paths, requests, hypotheses) rather than only natural-language conclusions. Never equate a candidate flag format with a validated flag.

### Web challenge reference
1. Inventory available request methods, parameters, cookies, redirect behavior, role conditions, content types and state transitions. Prefer source-backed assumptions where challenge code exists.
2. Model a minimal baseline/control for any claim about missing authorization or injection. Record exact request and response artifacts.
3. When a mechanism is already covered by Injection, XSS, API, Access/Auth or File/Path, send the lead via the common `hunter-lead --source ctf-solver` interface, including evidence references. Do not wait for the CTF solver to be stuck before delegating.
4. Reconcile reported vulnerabilities and actual challenge goal; a web flag may use a different condition from general bug bounty proof.

### Binary / Pwn reference
- Triage platform and format (ELF/PE), architecture, bitness, memory map and executable mitigations. Parse supplied files statically before executing unknown binaries.
- Create a reproducible input fixture and local trace for observed fault conditions. Distinguish crash from demonstrable control over execution or data.
- Use the correct isolated debugger and disassembler for available tools (e.g. GDB, x64dbg, Ghidra, radare2); retain the exact target binary checksum.
- For a simulated training service, use challenge-owned processes and accounts. Do not assume a public service permits arbitrary attacks.
- Preserve challenge-specific constraints in the task context supplied by Main.

### Reverse engineering reference
- Establish entry points, imports, exported functions, registration routines and data-flow from user-controlled inputs.
- Build a control-flow hypothesis; confirm using decompiled and disassembled views when available rather than trusting variable names in a decompiler.
- Inspect runtime strings, transforms, arithmetic, encodings, checksum routines, anti-debugging signals, and version-dependent behavior.
- Separate program functionality from malware triage. Escalate suspicious samples to Malware Analyst for nonexecuting classification or vetted sandbox analysis.
- Keep annotated offsets or function identifiers and minimal reproducible input/output examples.

### Cryptography reference
- Write down the exact scheme, representation, key/nonce characteristics and operations inferred from the challenge; avoid guessing from ciphertext appearance.
- Investigate encoding layers first (hex, Base64, custom alphabets), then cryptographic primitives. Check whether the task is about a cipher, protocol misuse or application integration.
- Assess key/nonce reuse, mode selection, padding, deterministic encryption, truncated comparisons and RNG assumptions where the challenge provides enough evidence.
- Use simple, independently checkable test vectors and verify candidate plaintext or secret against the challenge condition.
- Do not reuse recovered challenge secrets for unrelated targets.

### Forensics reference
- Work from immutable copies of provided disk, memory, log, document or packet artifacts; compute hash before analysis and after export.
- For file systems, identify partition boundaries and filesystem formats before carving. Maintain an extraction manifest and timestamp provenance.
- For memory dumps, confirm OS build and collection context before interpreting processes, handles, sockets or browser artifacts.
- For PCAP, enumerate protocols, endpoints and flows, correlate timestamps and extract complete application conversations when available. Never assume absence of a packet means absence of an action.
- For logs, align clocks/time zones and distinguish raw events from tool-inferred timelines.

### Steganography reference
- Begin with file magic/metadata and container validity rather than choosing a stego tool from the filename extension alone.
- Images: inspect metadata, trailing bytes, PNG chunks, color planes, bit planes and unusual dimensions; test known LSB methods when supported by the format.
- Audio: inspect metadata, waveform and spectrogram, encodings and timing patterns. Examine whether the provided data is truly lossless before assuming bit-level data survival.
- Text: inspect whitespace, invisible Unicode code points, encodings, line endings and ordering. Archive both raw bytes and normalized views.
- Archives/documents: inspect embedded objects and legitimate format structures. Extract untrusted content to a confined folder and avoid auto-running macros.
- Candidate strings are hypotheses; validate against explicit challenge checks or independent decoding.

### OSINT and mixed challenges
- Keep source URLs, capture timestamps and cross-check claims rather than treating a search snippet as proof. Use only information authorized by the challenge and Main's engagement.
- When the challenge crosses domains (forensics to web, crypto to reverse, Nmap service to Enterprise), submit distinct subtasks without pausing unrelated work.

### CTF outputs and state
- `challenge_id`, `challenge_category`, `assigned_agents`, `artifact_hashes`, `service_inventory_refs`, `hypotheses`, `executed_checks`, `validated_observations`, `candidate_flags`, `confirmed_flag`, `writeup`, `open_questions`.
- Retain separate challenge result classifications (`flag_observed`, `incomplete`, `not_reproduced`, `blocked`) and general security finding lifecycle states (`candidate`, `specialist_validated`, `poc_verified`, `manual_review`). Never promote a flag to a public vulnerability report automatically.


## V4.6.3.2 verification & architecture addendum

**Execution ledger:** Assign one unique challenge identifier to every item. For multi-stage tasks, track source artifact digest, hypothesis, independent control, reproduction note, result, stage owner and exact delegation target in the task context or the user/Main-designated challenge directory. Keep raw outputs immutable, redact provider/account secrets and hash derived artifacts when the available workflow supports it. Do not claim a dedicated SQLite CTF ledger or write files outside the designated challenge directory.

**Tool/source reliability:** Validate input file magic before parser selection; never assume a `.png` extension, disassembler pseudocode, LLM solution, or high-confidence score establishes facts. For pwn/rev, state host ABI, architecture and mitigations before using an isolated emulator/debugger. For crypto, require checkable test vectors or local challenge oracle. For forensic/stego, prefer non-destructive extraction with hashes.

**Service handoff:** Reconcile IP/port/protocol with the registered challenge scope, verify attribution of Nmap observations, and keep non-HTTP service endpoints structured rather than inventing HTTPS URLs. Use Main-mediated `nmap-service-lead --requested-by ctf-solver` when eligible.

**Cross-specialist dispatch:** Submit focused, deduplicated web/API/access-control leads to Main immediately with URL/HTTP method, prior evidence and confidence. Enterprise and Malware roles may assist without a sequential-failure precondition. Preserve separate result states for `flag_observed`, `flag_verified`, `blocked`, `not_reproduced` and general V4 bug-bounty findings; do not convert challenge completion into an independently verified public security finding.

**Safe acceptance:** Unit fixtures must demonstrate a duplicated CTF-to-Injection lead is deduplicated, out-of-scope handoffs fail closed, and no flag is treated as an independent PoC merely by its syntax. Live challenges require event-specific authorization and tool/runtime testing; the installer does not execute external challenges.
