# Upstream sources and integration note
Public reference: https://github.com/Monesgoda/offensive-Agent-s/tree/main/pentest/agents/ctf-solver
Source docs: [upstream agent.md](https://github.com/Monesgoda/offensive-Agent-s/blob/main/pentest/agents/ctf-solver/agent.md) and [upstream SKILL.md](https://github.com/Monesgoda/offensive-Agent-s/blob/main/pentest/agents/ctf-solver/SKILL.md) (external references; not locally bundled).
This package retains the reference URLs but uses original, integration-specific wording, instead of vendoring outside text blindly. The upstream `agent.md` covers Web/Pwn/Reverse/Crypto/Forensics/Stego/Privesc/OSINT and standard tools. The shared queue and evidence contract supersede upstream independent routing or storage assumptions.
