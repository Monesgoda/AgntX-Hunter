---
name: offsec-enterprise-cloud
description: AWS Azure and GCP cloud posture and access review.
---
# Cloud Security
Assess IAM and resource policies, storage exposure, identity delegation, instance metadata protections, logging, serverless permissions, key management and CI/CD secrets using approved inventory. Keep provider/account boundaries explicit. An exposed bucket URL is a lead until a concrete unauthorized access control is demonstrated with permitted test artifacts. Correlate with Infrastructure and API families, and retain detection or defensive logging context.

## Provider-specific assessment
**AWS:** check organization boundaries, IAM identity/resource policy evaluation, STS role trust and session limits, S3 bucket access, secrets, EC2 metadata controls, Lambda permissions, ECS/EKS task identity and CloudTrail coverage.
**Azure/Entra:** inspect tenant/app registration consent settings, RBAC role assignments, storage SAS lifetime, managed identity permissions, Key Vault access, subscription boundaries and Azure activity logs.
**GCP:** inspect organization/project IAM, service account impersonation rights, Cloud Storage IAM, workload identity, metadata protection, BigQuery datasets and audit-log settings.
**Cloud/Container overlaps:** correlate Kubernetes namespaces or pod identities to cloud identities before inferring account-level impact. Keep resource IDs, account/tenant and region in evidence.
For each lead, distinguish `policy allows action` from `unauthorized party could perform action`. Verify policy context using scoped test identity or static analysis, and avoid modifying shared cloud assets.
Produce normalized resource identifier, cloud provider, principal, permission, expected vs observed policy, evidence refs, confidence, potential effect, proposed remediation and detection events.
