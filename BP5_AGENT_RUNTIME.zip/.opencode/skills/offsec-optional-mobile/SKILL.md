---
name: offsec-optional-mobile
description: Optional user-enabled Android and iOS security review of authorized app builds and test accounts.
---
# Mobile assessment reference (opt-in)

Use only a provided IPA/APK, sandbox/emulator, explicit permission and test accounts. Check safe local data handling, application links/deep links, transport policy, permissions, auth/session handoff, backend API boundaries. Route backend IDOR to access-auth and API inventory to api; keep reproducible evidence without copying personal data. Not activated during normal Web engagement runs.
