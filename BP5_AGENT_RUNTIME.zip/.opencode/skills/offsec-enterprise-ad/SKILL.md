---
name: offsec-enterprise-ad
description: Active Directory and identity posture assessment based on authorized evidence.
---
# Active Directory Security
Analyze LDAP/Kerberos configuration, delegations, GPO inheritance, group/ACL entitlements, AD CS templates, certificate lifetimes and domain trusts. Use approved read-only inventory and BloodHound graphs as hypotheses rather than proofs. Check account lockout and network policy before credential-sensitive testing. Require separate approval for authentication coercion, password spraying, directory modifications or lateral movement. Link evidence to the affected security principal and recommend least-privilege fixes. Send overlapping authorization hypotheses to Access/Auth.

## Identity and Active Directory assessment sequence
1. Identify engagement tenant, forest/domain, read-only test identity and explicit permitted directory controllers before any LDAP or Kerberos operation.
2. Enumerate authorized users/groups/computers/service-principal relationships and effective group membership using approved read-only inventory.
3. Analyze group policy links, OU inheritance, domain trust direction, delegation, certificate template issuance permissions and account lockout policy.
4. Review service account privilege paths with BloodHound or comparable graph evidence: collect edge sources and date, not only tool-computed paths. A graph path is a risk hypothesis until the affected entitlement is verified.
5. For AD CS, separately assess enrollment, subject alternative name rights, certificate authentication mappings and administrative template ownership. Avoid issuing impersonation certificates automatically.
6. For Kerberos/LDAP, document policy, encryption choices, delegation configuration, authentication behavior and service exposure without requesting other users' secrets.
7. Link observed identity misconfigurations to a concrete permission boundary and defensive control. Escalation or write operations require targeted approval and rollback plan; approvals are not inferred from general web scope.
8. Deliver findings with account IDs minimized/redacted, host reference, policy snapshot, safe baseline/control, and supporting identity/evidence graph references.
