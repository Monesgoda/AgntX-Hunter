# Api — bounded assessment matrix

These are **method selection cues**, not exploit payloads or proof. Only test authorized targets; store real comparative observations and independently reproduce.

| Subtype | Audit target | Evidence required | False-positive guard |
|---|---|---|---|
| GraphQL Introspection / Batching / DoS | Schema exposure and resource limits | Safe low-complexity queries in authorized test schema show meaningful impact | Introspection availability is configuration choice, not necessarily bug |
| Unrestricted Resource Consumption | Quota, paging, request limits | Conservative repeated query evidence within engagement request limits | Do not stress production API or generate load |
| Unsafe Consumption of APIs | Upstream trust and validation | Test integration with trusted controlled upstream demonstrates boundary violation | Calling external API is normal |
| Improper API Inventory / Old Versions | Observed version surfaces versus documented inventory | Accessible deprecated endpoint retains a forbidden capability | Versioned path alone is not insecure |
| REST / Swagger / OpenAPI / Method Inventory | API specs, method declaration and response controls | Method differs from documented protected contract on disposable call | 200 response to OPTIONS alone is expected and not security evidence |

## Evidence checklist
- Capture known authorized scope, test account role, endpoint, method, consent and environmental constraints.
- Record baseline and at least two independent observations with status, response length, timing and relevant normalized content fingerprint.
- Classify `blocked`, `not_reproduced`, `inconclusive` explicitly. Avoid claiming a discovered version/header/URL proves a vulnerability.
- Attach redacted raw evidence and reproduce with a separate execution before POC verification.
- Never use public exploitation or bypass filters merely to make a proof succeed.
