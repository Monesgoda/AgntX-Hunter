# Request-Forgery — bounded assessment matrix

These are **method selection cues**, not exploit payloads or proof. Only test authorized targets; store real comparative observations and independently reproduce.

| Subtype | Audit target | Evidence required | False-positive guard |
|---|---|---|---|
| CSRF | Credentialed state-changing requests and token/origin controls | Two isolated test sessions reproduce state change without legitimate intent | GET with cookies or missing token string alone is inconclusive |
| SSRF | Server-initiated outbound request sources and destinations | Dedicated preapproved callback endpoint attributes request to server | Do not target private ranges/metadata without explicit contract |
| DNS Rebinding | Host validation before and after name resolution | Isolated lab host resolution changes demonstrate a verified trust-boundary gap | Dynamic DNS by itself does not establish exploitability |

## Evidence checklist
- Capture known authorized scope, test account role, endpoint, method, consent and environmental constraints.
- Record baseline and at least two independent observations with status, response length, timing and relevant normalized content fingerprint.
- Classify `blocked`, `not_reproduced`, `inconclusive` explicitly. Avoid claiming a discovered version/header/URL proves a vulnerability.
- Attach redacted raw evidence and reproduce with a separate execution before POC verification.
- Never use public exploitation or bypass filters merely to make a proof succeed.
