# Access-Auth — bounded assessment matrix

These are **method selection cues**, not exploit payloads or proof. Only test authorized targets; store real comparative observations and independently reproduce.

| Subtype | Audit target | Evidence required | False-positive guard |
|---|---|---|---|
| IDOR / BOLA | Object-owner checks per endpoint | Two authorized test principals see inconsistent object access in redacted records | Different 404/403 alone is not access |
| BFLA / Privilege Escalation | Endpoint permissions vs roles | Low-privilege test identity exercises denied functionality in disposable flow | UI button hidden is not authorization |
| BOPLA / Mass Assignment | Property-level writes and serializers | A test-only field unauthorized for role changes and persists in test record | Property accepted but ignored is not exploit |
| Unprotected Admin / HTTP Verb Tampering | Every method on every protected operation | Minimal allowed method comparison proves missing control | OPTIONS response is not a bypass |
| Authentication / 2FA Bypass | Primary and secondary factors and state machine | Disposable test account demonstrates sensitive authenticated action without required factor | Different login error codes do not prove bypass |
| Username Enumeration / Brute-Force Controls | Responses and throttling under safe low-volume tests | Statistically consistent enumeration difference or absent controls within allowed policy | Do not brute-force or spray credentials |
| Password Reset Poisoning / Logic | Reset token issuer, recipient, host trust | Disposable account receives incorrectly bound recovery action | User controllable header alone is not impact |
| Sessions / Fixation / Remember Me | Token rotation, persistence, entropy indicators | Two controlled sessions demonstrate security-significant token reuse | Subjective token appearance is not randomness proof |
| JWT | Token validation, key rotation, audience | Offline verifier or disposable-signed token demonstrates broken invariant | Presence of JWT is not a flaw |
| OAuth / OAuth CSRF | State, nonce, redirect URI and PKCE flow | Disposable OAuth app misbinds a controlled identity or authorization flow | Redirect URI matching by itself is not exploitable |
| SAML | Signature, audience, destination, issuer, response binding | Signed lab assertions demonstrate a trust-boundary violation | XML structure alone is no verification |

## Evidence checklist
- Capture known authorized scope, test account role, endpoint, method, consent and environmental constraints.
- Record baseline and at least two independent observations with status, response length, timing and relevant normalized content fingerprint.
- Classify `blocked`, `not_reproduced`, `inconclusive` explicitly. Avoid claiming a discovered version/header/URL proves a vulnerability.
- Attach redacted raw evidence and reproduce with a separate execution before POC verification.
- Never use public exploitation or bypass filters merely to make a proof succeed.
