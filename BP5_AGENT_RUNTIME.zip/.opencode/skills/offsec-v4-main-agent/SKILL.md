---
name: offsec-v4-main-agent
description: Detailed coordination contract for the active V4 operator.
---
# V4 Orchestrator skill

Read `.opencode/agents/offsec-v4-operator.md` and the canonical V4 family registry `pentest/agents/v4-index.json`.
Original detailed source remains intact at `legacy/skills-original/offsec-main-agent/SKILL.md` (native) or `legacy/skills-original/offsec-main-agent/SKILL.md` (global installation); use it for historical background only where consistent with V4 scope and evidence rules.

## External authority
The Python scheduler, fixed catalog (`pentest/framework/catalog.py`) and central CLI determine routing, authorization and state changes. The LLM performs authorized primary hunting, but uses the fixed family catalog and central queue for all specialist delegation and cannot unilaterally verify proof claims.

## Concurrent start and checkpoint
Start the recon worker asynchronously, then actively hunt independently during recon execution. The coordinator itself still runs recon plus cache-only misconfiguration review. Cache review must not independently make network requests. The live scheduler's single dispatch pump can process committed leads during recon; Main only submits leads. On the completion checkpoint the coordinator validates report hashes and the atomic done signal and commits the remaining deduplicated tasks.

## Shared state ownership
Only the CLI writes to V4's SQLite. Main uses `init-db`, `run`/`start`, `run-status`, `tasks`, `hunter-lead`, `hunter-observations`, `nmap-service-lead`, `knowledge`/`search-knowledge` and `dashboard` as appropriate. Managed family workers own `submit`/`complete`; the independent worker owns `verify`. CLI `review` is disabled: approval is protected human Dashboard review only. The V4 store owns its current schema; do not read or modify external historical databases.

## Review sequence
Potential signals → specialist's real bounded observations → independent fresh verification → human Dashboard review. Distinguish blocked/inconclusive from proven and never invent POC or exploit impact.

## Family catalog
Injection, Client-Side, Access/Auth, Request Forgery, File/Path, Business Logic, Infra/Misconfig, API and LLM Security. Each family has its own active agent/skill and only technique references compatible with the V4 contract.

## Respect original assets
The runtime package includes 155 reference playbooks, the read-only technique library under `legacy/skills-original/`, and the V4 knowledge corpus; retrieve them selectively using the knowledge CLI. This release uses `offsec-v4-operator` by default. Historical skill texts may contain retired role instructions, but these are reference data and are never active routes. Standalone V3 executables are not shipped.

## V4.6: Active hunter workflow

Launch Recon via `python -m pentest.framework.cli start --engagement ENG ...`, then continue scoped analysis and low-impact checks without waiting. Record every potential XSS/SQLi/IDOR/AI-security issue immediately with the `hunter-lead` CLI. If no family owns a root cause, record an `unassigned_observation` rather than hallucinating a new specialist. `start` without `--live` is non-live and does not auto-dispatch. During an explicitly authorized `start --live`, the scheduler exclusively owns dispatch: never launch `dispatch --execute` or `dispatch-poc --execute` from Main while its pump is active. A separate manual execution requires an authorized coordinator to reconcile worker ownership first. Existing evidence references can accompany the lead; they cannot count as specialist or independent verification. After recon's verified atomic done signal, the reconciled candidate ledger prevents repeat work.

For source availability, use `offsec-v4-code-auditor`; it only produces unverified code-grounded leads. The CTF solver and Enterprise/Malware specialists are regular cooperating subagents with the same central authorization and scope context, not independent modes. They can delegate work immediately across the shared queue and continue in parallel. CTF flags are not security findings without independent confirmation. Mobile skill is available where relevant.


**V4.6.3.2:** After supported specialist dispatch, the active pump invokes the persisted independent POC queue. Every `specialist_validated` finding has at most one automatic attempt until a qualified operator deliberately reconciles its status. Unsupported findings remain visible as verification gaps; all nine families may qualify for weaker GET replay when the required target/control receipts exist. Never treat a `done` task or a CTF flag as `poc_verified`.
