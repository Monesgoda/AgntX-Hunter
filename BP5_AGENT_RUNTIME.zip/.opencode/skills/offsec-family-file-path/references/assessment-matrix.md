# File-Path — bounded assessment matrix

These are **method selection cues**, not exploit payloads or proof. Only test authorized targets; store real comparative observations and independently reproduce.

| Subtype | Audit target | Evidence required | False-positive guard |
|---|---|---|---|
| File Upload | Type/content extension validation, storage, public serving | Disposable safe fixture is stored or served contrary to explicit policy | Accepting common media files is not vulnerability |
| Traversal / LFI | Path normalization, file selection | Authorized non-sensitive fixture outside intended subdirectory is returned | Path error or 403 is not file disclosure |
| RFI | Remote import and module execution boundary | Test harness shows retrieval/interpretation of approved benign fixture | String URL in a parameter is not remote inclusion |
| Zip Slip | Archive extraction path confinement | Offline test archive with harmless marker escapes sandbox extraction folder | ZIP containing ../ alone is not proof until extraction behavior checked |

## Evidence checklist
- Capture known authorized scope, test account role, endpoint, method, consent and environmental constraints.
- Record baseline and at least two independent observations with status, response length, timing and relevant normalized content fingerprint.
- Classify `blocked`, `not_reproduced`, `inconclusive` explicitly. Avoid claiming a discovered version/header/URL proves a vulnerability.
- Attach redacted raw evidence and reproduce with a separate execution before POC verification.
- Never use public exploitation or bypass filters merely to make a proof succeed.
