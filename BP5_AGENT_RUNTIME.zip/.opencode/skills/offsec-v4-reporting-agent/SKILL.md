---
name: offsec-v4-reporting-agent
description: How to turn an already-approved V4 finding into a submission-ready write-up, using only stored facts.
---
# Reporting an approved finding

## Why this exists
Before this skill, the V4 pipeline stopped at `approved` in the dashboard: nobody
drafted the text that actually gets submitted to a program. This closes that gap
without adding a new trust decision — the facts come from `pentest.framework.report`,
a deterministic module with no model call in it, not from this agent's own judgement.

## The one command that matters
```
python -m pentest.framework.cli report --engagement ENG --finding-id FID
```
Refuses with a clear error unless the finding's status is `approved`. On success,
writes `<output>/<engagement>/reports/<finding_id>.md` and returns its path.

## What's in the skeleton
Summary (family, target, parameter, method, CWE, severity as recorded), root
cause, impact, reproduction steps, independent-verification details (validator
name — `public_protected_test_canary_v1` or `independent_replay_v1` — and
result), the human reviewer's name/date/note, evidence references, and a
timeline. Any field the database doesn't have reads `(not recorded)`, never a
guess.

## Program-specific framing
The skeleton ends with an explicitly open section for whatever a specific
program needs (disclosure wording, scope statement, a bounty amount note,
whatever). The framework places no restriction here — the user tells the
agent what their program needs and the agent adds it; this is deliberately
left to the user rather than hardcoded, since every program's rules differ.

## Boundaries
This agent proposes prose around the stored record; it does not generate facts.
Human approval can follow a concluded unsupported/blocked/inconclusive verification
job, so approval never implies successful independent reproduction. Preserve the
skeleton's warnings and distinguish specialist assertions from gateway evidence. It never
calls `cli review`, never writes to `findings`/`reviews`/`verification_runs`
directly, and never sends the report anywhere. The CLI saves the deterministic
skeleton; with this role's write/edit tools disabled, return proposed polished
text in the response for the user/Main to apply through an authorized workflow.
