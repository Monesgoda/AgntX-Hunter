---
name: offsec-recon-nmap
description: Nmap service inventory stage for the Recon agent, with scoped XML evidence and advisory handoff.
---
# Nmap Recon
Activated by authorized live Recon only, or via offline `nmap.xml` capture. Parse Nmap XML as inert input, record in-scope host/port/protocol/state/service metadata and its source; save hash and manifest. Do not label a port as a vulnerability. Main reads `nmap_services.jsonl`, chooses Enterprise or CTF based on task context and can hand off other services to Infra as needed. Only Main schedules a normal cross-specialist task; the Recon agent never independently assumes that a service should be exploited. Do not enumerate out-of-scope IP ranges and respect exclusions and rate ceilings.

## Execution options
- `--live` authorized recon automatically attempts Nmap when available. It scans the exact approved hostname list already produced in Recon, never an inferred CIDR or all hosts of a suffix.
- If `allowed_ports` is set in the engagement, the **actual Nmap command** scans only those ports; `out_of_scope_ports` are not scanned. Optional `nmap_ports` is an explicit comma/range subset and cannot override authorization.
- Without `allowed_ports` or `nmap_ports`, use a conservative top-100 TCP services inventory and exclude any specifically prohibited ports, with host timeout and bounded rate; larger authorized scans need deliberate scope config.
- `--live` with missing Nmap records a clear coverage gap; offline XML import still works. Nmap is never treated as a vulnerability scanner by itself.

## Offline and normalized output
- Import captured `nmap.xml` alongside other recon files. Refuse oversized XML documents or DTD/ENTITY definitions.
- The `nmap_services.jsonl` artifact records host, port, protocol, state, service, product, version and `verdict=observation`; it is included in the atomic report manifest with SHA-256.
- A host is retained only if its identity maps to the allowed scope; filtered-out addresses/ports do not get routing tasks. Unknown version and ambiguous service names remain explicit, not guesses.
- Main chooses `nmap-service-lead --requested-by main-hunt` to hand off to Enterprise, or `--requested-by ctf-solver` for a CTF-requested review. Both use the same SQLite ledger and do not create a vulnerability finding.
- Preserve scanned targets and the exact requested port profile as traceable recon metadata when possible; enrich future service observations with scan provenance rather than overwriting original captures.
