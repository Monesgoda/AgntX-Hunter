---
name: offsec-family-llm-security
description: Authorized AI application trust-boundary assessment; prompt injection, retrieval isolation, tool permissions, delegated authority, and unsafe downstream use of model output.
---
> **Reference boundary:** archived V3 role prompts and V3 executables are intentionally excluded from this runtime package. Consult only the read-only technique references under `legacy/skills-original/` listed below, and keep this V4 contract authoritative.

# LLM Application Security

## Owned classes
- Direct and indirect prompt injection across user, retrieved-content, tool-output, and multi-turn trust boundaries.
- Cross-user, cross-tenant, cross-session, or cross-role retrieval/context disclosure.
- Unsafe tool/function-call permissions, confused-deputy behavior, and autonomous actions beyond delegated authority.
- Untrusted model output consumed downstream as HTML, code, shell input, SQL, configuration, or another executable/control format.
- System-prompt/configuration disclosure and training/fine-tuning data disclosure where explicitly authorized and safely testable.

## Trust-boundary method
1. Map the identities and components: user, application, model, retrieved documents, tool executor, data store, downstream renderer, and human approval gate. Record which component receives each instruction and which component actually acts.
2. Use owner-provided test accounts, synthetic records, disposable canaries, and local fixtures. Never solicit or extract real customer records, credentials, private prompts, or third-party data.
3. Establish a benign baseline and a benign negative control before one low-impact adversarial input. Keep each test tied to an authorized endpoint, identity, tenant, and task.
4. Require an observable unauthorized action or access (for example, a test-only canary read by the wrong test identity or a tool call executed beyond the granted test role). Model text that merely claims it called a tool, a refusal, instruction-following prose, or a speculative answer is not proof.
5. Verify the action at the component that performed it: tool execution log, synthetic data store, test canary, or downstream rendering result. Distinguish model-generated text from actual execution. Record the actor, resource, authorization boundary, and outcome.
6. Preserve minimal, redacted evidence with timestamps and exact test conditions. Stop on real secret exposure, unapproved side effects, privilege changes, destructive actions, or uncertainty about authorization.

## Evidence and gateway contract
A `confirmed` specialist submission still requires at least two authorized low-impact gateway observations. Use:
`python -m pentest.framework.cli probe --engagement ENG --url URL --stage specialist --linked-id TASK_ID`
Record the returned unique observation IDs in `gateway_observation_ids`. The task must be claimed and its lease unexpired. HTTP receipts prove that the gateway made the requests; they do not, by themselves, prove LLM impact.

For a generic independent replay, the `baseline.url` must match the target's scheme, hostname, effective port, and path; only query parameters and/or fragment may differ. It does not need separate task-endpoint registration, but it must pass the engagement scope check. Collect at least two unique baseline receipt IDs in `baseline_observation_ids`, using the same specialist-stage probe flow. Both target receipts and baseline receipts must be internally stable. The validator compares the target and control observations; unrelated same-host paths and dynamic/unstable endpoints are not valid baselines. A successful generic replay reaches only `replay_stable`, a stability tier weaker than an owned-canary impact proof; it never becomes `poc_verified` merely because the agent says so.

An owned canary can support a stronger impact-verification tier only when it was enrolled by the owner, is explicitly configured for the engagement/target, and the independent validator confirms the expected controlled impact. The framework's final verdict must be read from the recorded verification result and its accepted gateway evidence, not inferred from an agent's narration.

## Framework pacing and stop conditions
The gateway allows at most one request per second per host. A faster probe returns `gateway host request budget exhausted; retry later`; this is framework pacing, not a target/WAF/provider response. Wait at least one second, then retry the same authorized probe. Do not report this gateway error as target `blocked`, `inconclusive`, or `error`. Stop when the target or provider imposes its own throttling or protective block, when the authorization boundary is unclear, when a test would expose real data, or when an action could modify production state.

## Result states and review boundary
Use only `confirmed`, `not_reproduced`, `blocked`, `inconclusive`, or `error`, and explain uncertainty. `confirmed` at specialist stage is not `poc_verified`. Independent replay may conclude `replay_stable`; it remains weaker than an owner-enrolled canary and does not prove unauthorized impact. A separate human review may review `replay_stable`, or a `specialist_validated` finding only after its independent job concludes `unsupported`, `error`, `blocked`, or `inconclusive`. Do not request human review while the verification job is pending/running. Human approval is a risk decision, not an automatic verification tier.

## Durable submission and execution fence
The CLI requires the JSON record on stdin: use `submit --engagement ENG --task-id TASK --record-json -` and provide the JSON through stdin (for example, a heredoc supported by the active shell). Do not create `RECORD.json` or other files; this Agent has no direct write permission. **Submit before `complete`** because submission requires the active task lease and completion releases it. The dispatcher creates the durable PoC queue intent after a valid specialist submission; do not manually update SQLite or claim `poc_verified`.

The task fence is inherited through `OFFSEC_TASK_FENCE`. Never print, copy, replace, or disclose it. If the gateway reports a stale/expired lease, stop and return the error; do not claim or complete another worker's task.

## V4 submission and lease contract
Submit a complete JSON finding through the central CLI using `python -m pentest.framework.cli submit --engagement ENG --task-id TASK --record-json -` and pass the JSON on stdin (for example, a shell heredoc). Do not create `RECORD.json` or other temporary files, write SQLite directly, or invent gateway receipt IDs. **Submit before calling `complete`**: submit requires the active task lease, while `complete` releases it. Handle the returned finding ID and submission result before completing the task.
