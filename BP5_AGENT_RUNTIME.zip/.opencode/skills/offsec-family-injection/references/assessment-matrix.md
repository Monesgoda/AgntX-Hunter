# Injection — bounded assessment matrix

These are **method selection cues**, not exploit payloads or proof. Only test authorized targets; store real comparative observations and independently reproduce.

| Subtype | Audit target | Evidence required | False-positive guard |
|---|---|---|---|
| SQL / NoSQL Injection | Parameter type and query context | Repeatable control-vs-modified-input behavior consistent with backend interpretation | ORM errors or caching alone are not proof |
| Command Injection | Server-side command invocation boundary | Harmless environment-specific marker reproduced on an approved lab fixture | Shell metacharacters appearing in input logs are not execution |
| XXE | XML parser settings and entity resolution | Controlled parser resolution observation with a pre-approved benign fixture | A valid XML response is not external entity expansion |
| SSTI | Template engine and interpolation context | A repeatable safe computed marker in the template context | Reflected braces alone are insufficient |
| LDAP Injection | Directory query construction and filter escaping | Authorization-respecting differential results in test directory | Unknown user responses alone can indicate enumeration only |
| HTML Injection | Output encoding and trusted rendering | Rendered HTML element reaches wrong trust boundary | Literal escaped text is safe output, not injection |
| CSV / Formula Injection | Export formats and spreadsheet evaluation | Benign formula-handling proof on disposable CSV with explicit operator review | Seeing `=` in text does not imply client evaluation |
| SSI Injection | Server-side include parsing and enabled handler | Sandbox-only parsing behavior proven with harmless marker | Server banner is a hint only |
| CRLF / HTTP Response Splitting | Header construction and decoded input | Distinct safe header-boundary manipulation evidenced by separate response | A newline character in body is not splitting |
| SMTP / Email Header Injection | Message header interpolation, recipient controls | Controlled test inbox shows injected header with no external recipients | User-provided display name in body is not header injection |
| HTTP Header Injection | Application-built response headers | Observable controlled header value and boundary change | Simple reflection in a header is not necessarily unsafe |
| Server-Side Parameter Pollution | Backend request serialization and duplicate parameter semantics | Observed backend-only interpretation delta under allowed calls | Duplicated keys without effect are not proof |
| Insecure Deserialization | Untrusted serialized payload consumption | Safe local harness shows sensitive object boundary bypass | Base64 or JSON presence is not deserialization risk by itself |

## Evidence checklist
- Capture known authorized scope, test account role, endpoint, method, consent and environmental constraints.
- Record baseline and at least two independent observations with status, response length, timing and relevant normalized content fingerprint.
- Classify `blocked`, `not_reproduced`, `inconclusive` explicitly. Avoid claiming a discovered version/header/URL proves a vulnerability.
- Attach redacted raw evidence and reproduce with a separate execution before POC verification.
- Never use public exploitation or bypass filters merely to make a proof succeed.
