---
name: poc-creation
description: "Build a self-contained proof-of-concept for a confirmed, authorized security finding: a stdlib-only Python script with a captured working-run transcript, or a single HTML/SVG file for a client-side bug. Use after a finding is validated and before finalizing its report."
metadata:
  tags: [security-testing]
---

# PoC Creation

## Configure this skill before use

This public version intentionally contains no private hosting details, internal service
names, local workspace layout, or organization-specific credentials. Before enabling it,
adapt the following items to your own environment:

1. **PoC hosting:** replace `https://poc.example.invalid` and the illustrative
   `/path/to/your/publish.py` command with a publisher you control. It should return a
   stable, public HTTPS URL and preserve that URL when a file is republished.
2. **Report submission:** replace `/path/to/your/submit.py` with your reporting workflow,
   or remove the integration and insert PoC links into reports manually.
3. **Skill paths and templates:** examples assume no particular repository layout. Point
   any helper or template reference at your installation, or keep the snippets directly
   in the generated PoC.
4. **Request attribution:** `X-PoC-Actor` is a neutral example header. Rename it if your
   team has a standard, or omit it when a target rejects unsigned custom headers.
5. **Proxy settings:** the examples use `http://127.0.0.1:8080`. Change this to the local
   intercepting proxy used in your authorized testing environment.
6. **Credential policy:** decide whether your disclosure program permits scoped test
   credentials in hosted artifacts. Never publish personal credentials, infrastructure
   secrets, model-provider keys, SSH keys, or credentials for an unrelated target.
7. **Authorization and safety:** use this skill only on targets you are authorized to
   test. Adapt all examples to the program's scope, rate limits, data-handling rules, and
   prohibited actions.

All example domains use the reserved `.invalid` suffix and will not resolve until replaced.

## Every confirmed finding needs a working PoC

Build and verify the PoC before submitting the finding. The executable entry point is one
`.html`/`.svg` file for a client-side bug or one `.py` file for a server-side bug. The PoC
must demonstrate the impact being claimed; a generic `alert(1)` is not sufficient evidence
for a stronger claim such as account takeover.

A generic publish-and-republish loop looks like this:

```bash
python3 /path/to/your/publish.py poc.html
# -> https://poc.example.invalid/p/<stable-id>/poc.html
# Open and test it, fix the local file, then publish again to the same URL.
python3 /path/to/your/publish.py poc.html
```

For every server-side `.py` PoC, produce a same-directory, same-stem pair: `name.py` and
`name.txt`. Run the reviewed local script and capture its real output into `name.txt`;
publish either artifact only when the publication gate below permits it:

```bash
export PROXY=http://127.0.0.1:8080
export HTTPS_PROXY="$PROXY"
set -o pipefail
# Verify your OWN local copy -- you already wrote this file, there is no
# reason to round-trip it through a hosted URL and pipe the fetch straight
# into python3 just to test it. Piping remote content into an interpreter
# bypasses every gateway/scope/rate-limit control in this framework, and the
# hosted copy should only ever be a byte-identical publish of what you
# already verified locally, never the thing you test against.
python3 /path/to/your/poc/name.py > name.txt 2>&1
rc=$?
cat name.txt
test "$rc" -eq 0
python3 /path/to/your/publish.py name.txt
```

Do not publish the transcript until your local run exits successfully and its output proves
the claimed impact. The transcript must be the verbatim output of that local run, not a
handwritten summary and not output from running the hosted/piped copy.

Put both URLs in the report at the top of Steps to Reproduce. Place the absolute `.txt` URL
directly below the exact two-line save-then-run commands, with no intervening prose.
Archive both files with the report when the reporting platform supports attachments.

Client-side `.html`/`.svg` PoCs do not require a `.txt` transcript when the working result is
visible in the hosted page itself.

If a reliable PoC genuinely cannot be built, say so explicitly in the report and explain
why. Do not silently submit a report that appears to promise an executable reproduction.

The goal for a server-side PoC is two commands a triager can paste on a clean machine:

```bash
curl -s https://poc.example.invalid/p/<stable-id>/idor-export-orders.py -o idor-export-orders.py
python3 idor-export-orders.py
```

Never pipe a remote fetch into an interpreter: save it first so the downloaded bytes can be
inspected. This framework's own runs always use the local, already-reviewed copy.

## The central rule: self-contained

The Python PoC must run on a machine that has nothing but `python3`:

- **No dependencies.** Use the standard library: `urllib`, `http.client`, `json`, `ssl`,
  `os`, `sys`, `base64`, and `re`. Do not require `requests`, `pip`, or `jq`.
- **No author-machine file paths.** Do not read tokens, cookies, or IDs from a local project
  directory. Anything required by the PoC must be embedded, collected safely from the user,
  or fetched at runtime from a public target endpoint.
- **No private local state.** Do not depend on proxy-history IDs, internal job IDs, private
  session stores, mounted drives, or the author's shell configuration.
- **No private infrastructure references.** The published file must not name internal
  services, assessment systems, hosts, repositories, or organization-specific tooling.
- **No required proxy.** Proxy support is useful for inspection, but the PoC must also run
  directly.

Ask: if this file were emailed by itself to a triager, would it run and explain the bug?

## Credentials

Authentication is usually the largest source of reproduction friction. Prefer credentials
that remain valid long enough for triage, while complying with the target program's rules.

In priority order:

1. **Unauthenticated:** require no credentials when the bug does not need them.
2. **Stable test-account login:** if policy permits, have the PoC log in using dedicated
   program test accounts, maintain separate cookie jars, and continue automatically.
3. **Scoped target token or session:** use only when necessary and permitted. Treat the
   hosted artifact as public, even when its URL is hard to guess.
4. **Prompt for target credentials:** use only as a last resort, and read through the
   controlling terminal rather than stdin.

Only use accounts created or issued for the authorized target. Never embed personal
credentials, credentials belonging to real users, secrets for another program, publishing
credentials, cloud credentials, SSH keys, or private automation tokens.

Private session-management systems may be useful while authoring, but they must not become
a dependency of the public PoC. Before publishing, replace private session retrieval with a
stable target login, a permitted scoped target token, or a clear prompt for target auth.
Remove any private URLs, credentials, session bundles, service names, and local identifiers.

## Make HTTP traffic inspectable

Every `.py` PoC should support an optional intercepting proxy. If interception is expected,
allow TLS verification to be disabled explicitly so a local proxy certificate does not break
the reproduction. Do not silently weaken TLS in unrelated production code.

```python
import os
import ssl
import urllib.request

ctx = ssl.create_default_context()
if os.environ.get("POC_INSECURE_TLS") == "1":
    # Explicit local interception opt-in only; default requests verify TLS.
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

proxy = os.environ.get("PROXY") or os.environ.get("HTTPS_PROXY") or ask_proxy()
handlers = [urllib.request.HTTPSHandler(context=ctx)]
if proxy:
    handlers.append(urllib.request.ProxyHandler({"http": proxy, "https": proxy}))
opener = urllib.request.build_opener(*handlers)
```

Support both paths:

- `PROXY=http://127.0.0.1:8080` for headless, piped, and CI runs.
- An interactive prompt when a controlling terminal exists, where blank means direct.

Export the proxy so both the script download and its HTTP requests can be observed.
Never include userinfo in a proxy URL (`http://user:password@proxy:8080`): it is passed
to every agent subprocess and would be leaked into the transcript or a published PoC.
Use a proxy that needs no in-URL credential:

```bash
export PROXY=http://127.0.0.1:8080 HTTPS_PROXY=http://127.0.0.1:8080
curl -s https://poc.example.invalid/p/<stable-id>/poc.py -o poc.py
python3 poc.py
```

### Tag requests by actor

For multi-actor PoCs, add an identifying header to each request when the target tolerates
unknown headers:

```http
X-PoC-Actor: attacker
```

Define it once and apply it from the actor's request method:

```python
ACTOR_HEADER = "X-PoC-Actor"
h.setdefault(ACTOR_HEADER, self.name)
```

This makes near-identical requests from separate sessions distinguishable in an intercepting
proxy. If a signed-request scheme or filtering layer rejects unexpected headers, omit it and
say so in a source comment.

For a client-side cross-origin PoC, do not add a custom actor header to a credentialed
`fetch` unless the attack genuinely allows it; a custom header triggers a CORS preflight and
may invalidate the test. Identify the victim in the on-page narration instead.

## Interactive input under a saved-script run

When a script is saved first and run as `python3 poc.py`, stdin is the controlling terminal
as expected, so `input()` and `sys.stdin` read from the user rather than from source bytes.

Use a helper that writes the prompt to stdout and reads the controlling terminal in read-only
mode. That is `/dev/tty` on POSIX; on Windows the console device is `CONIN$`/`conin$`, because
`/dev/tty` does not exist there and `open("/dev/tty")` raises `OSError`. Accept the same value
through an environment variable for non-interactive runs:

```python
import os
import sys

def _open_terminal():
    # POSIX controlling terminal, then the Windows console devices, both read-only.
    for path in ("/dev/tty", "CONIN$", "conin$"):
        try:
            return open(path, "r", encoding="utf-8", errors="replace")
        except OSError:
            continue
    return None

def tty(prompt, env_name=None):
    if env_name and os.environ.get(env_name):
        return os.environ[env_name]
    print(prompt, end="", flush=True)
    terminal = _open_terminal()
    if terminal is None:
        hint = f" Set {env_name}." if env_name else ""
        raise RuntimeError(f"No controlling terminal is available.{hint}")
    with terminal:
        return terminal.readline().rstrip("\r\n")

def ask_proxy():
    if not sys.stdout.isatty():
        return None
    try:
        return tty("Proxy URL (blank for direct): ") or None
    except RuntimeError:
        return None
```

Important details:

- Open the controlling terminal read-only: `/dev/tty` on POSIX, `CONIN$`/`conin$` on Windows.
  A combined `r+` open fails in some shells and CI wrappers.
- Do not silently swallow a missing controlling-terminal error for required input.
- Always offer an environment variable such as `TOKEN` or `VICTIM_ID` as a headless path.
- Test the real TTY path as well as the environment-variable path before claiming it works.

## IDs and object references

Do not ask the triager to hunt for an object ID:

- Discover it after authentication through a list, search, or `/me` endpoint.
- In a cross-account authorization test, create and use objects owned by test accounts you
  control. Never enumerate or modify unrelated users' data.
- If a choice is genuinely required, fetch the available test objects and let the user
  select one through the TTY helper.

## Structure: setup, control, exploit, proof

Make the security boundary and the bypass visible:

1. **Setup:** create or log in the actors, create required test objects, and identify each
   actor explicitly.
2. **Control:** show the action succeeding for the rightful owner and being denied to the
   unauthorized test actor through the intended path.
3. **Exploit:** apply the smallest safe bypass.
4. **Proof:** show that the unauthorized test actor receives the protected result or that a
   safe, reversible state change occurred.
5. **Cleanup/follow-on:** restore owned test data when safe and describe closely related
   impact without expanding into bulk access or destructive testing.

Print an unmistakable verdict. The triager should understand the bug from stdout without
needing to read the source.

## Narrate every request

Print one line per request, in execution order, showing who sent it, the method and path,
the response, and why it matters:

```text
=== Setup: establish actor identities ===
[attacker] POST  /api/login       -> 200                     - logged in as attacker test account
[victim  ] POST  /api/login       -> 200                     - logged in as victim test account
[attacker] GET   /users/me        -> 200 {"id":5,...}        - attacker test account is id 5
[victim  ] GET   /users/me        -> 200 {"id":6,...}        - victim test account is id 6

=== Control: intended access control ===
[victim  ] GET   /users/6         -> 200 OK                  - owner can read the object
[attacker] GET   /users/6         -> 403 Access Denied       - expected denial

=== Exploit: vulnerable alternate path ===
[attacker] GET   /users-v2/6      -> 200 {"email":"test…"}  - VULN: non-owner reads test data

VULNERABLE: the alternate endpoint returned an object that the intended endpoint denied.
```

Rules:

- Narrate every request, including login, signup, object creation, and cleanup.
- Prefix each line with the actor, padding names when helpful for readability.
- Show only the response fields needed to establish the result. Avoid unnecessary personal
  data and never print infrastructure or publishing secrets.
- End each line with what it establishes, not merely what endpoint was called.
- Identify both actors before exercising an authorization bug.
- Show both sides of the control: the owner succeeds and the non-owner is denied.
- Mark the vulnerable request with `VULN` and end with a concise verdict.
- Give every actor a separate cookie jar. A shared jar can accidentally send the victim's
  session under the attacker's label and invalidate the proof.
- Keep testing minimal and safe: use owned test accounts, avoid bulk enumeration, and do
  not perform irreversible or service-impacting actions.

## Client-side HTML or SVG PoCs

Use one file with no external assets, hosted as `text/html` or `image/svg+xml`:

- For a zero-click attack, accept victim-specific values from the query string and auto-run
  on load, for example `?target=test-object&autorun=1`.
- Treat input fields and buttons as testing conveniences. The hosted URL should express the
  real interaction requirement accurately.
- Inline CSS and JavaScript. Do not depend on a CDN, framework, or external image.
- Narrate requests and results on the page so the visible output is self-explanatory.
- Avoid `mode: "no-cors"` when the claim requires reading a response.
- Do not add custom cross-origin headers that introduce a preflight absent from the real
  attack.
- Never collect or transmit data from anyone other than the researcher's authorized test
  accounts.

## Hosting contract

Choose a publisher that provides the following behavior:

- A stable HTTPS URL is available before report submission.
- Republishing a file updates content without changing the URL.
- `.py` and `.txt` are served as `text/plain`; `.html` as `text/html`; `.svg` as
  `image/svg+xml`.
- Files are downloadable without the author's local filesystem or authenticated tooling.
- Access controls and retention match the disclosure program's requirements.
- The publisher rejects or warns about disallowed secrets according to your policy.

Use descriptive filenames such as `idor-export-orders.py`, `priv-esc-role-update.py`, or
`stored-xss-profile-bio.html`, not `poc.py`.

An optional reporting integration might look like this after you replace it with your own:

```bash
python3 /path/to/your/submit.py \
  --title "..." --severity high \
  --description /path/to/report.md \
  --poc /path/to/idor-export-orders.py \
  --poc /path/to/idor-export-orders.txt
```

If no integration exists, upload or link the artifacts manually and verify every link from
a clean, unauthenticated browser session where program policy allows public access.

## Ordering inside Steps to Reproduce

Keep the report's normal Summary and Details sections. Inside **Steps to Reproduce**, use:

1. The single PoC entry point: one command for Python or one link for HTML/SVG.
2. The working transcript URL for a Python PoC.
3. Optional manual steps.
4. Supporting evidence such as screenshots or raw captures.

Server-side example:

~~~markdown
## Steps to Reproduce

Run this command; it requires only Python 3:

```
curl -s https://poc.example.invalid/p/<stable-id>/idor-export-orders.py -o idor-export-orders.py
python3 idor-export-orders.py
```

**Working PoC transcript:** https://poc.example.invalid/p/<stable-id>/idor-export-orders.txt

Expected output ends with `VULNERABLE: the export endpoint returned an object that the
intended endpoint denied.`

### Manual steps

1. ...
2. ...

### Evidence

- Response demonstrating the result: <evidence URL>
- Screenshot: <evidence URL>
~~~

Client-side example:

~~~markdown
## Steps to Reproduce

Open the following link while logged into an authorized test account:

https://poc.example.invalid/p/<stable-id>/stored-xss-profile-bio.html

The page performs and narrates the minimal reproduction.

### Manual steps

1. ...

### Evidence

- Screenshot of the result: <evidence URL>
~~~

Use one primary entry point. Additional cross-checks may be supporting files, but the triager
should not have to decide which of several PoCs reproduces the claimed bug.

## Before shipping

1. Run your own local copy of the artifact (`python3 /path/to/your/poc/<name>.py`), never a fetch-and-pipe of the hosted URL into an interpreter -- you already have the file; that pattern bypasses every gateway/scope control here and is not something this framework's own verification step should do. Only the triager, independently and on their own machine, downloads and runs the hosted copy later.
2. For Python, capture that successful local run into the same-stem `.txt` transcript.
3. Confirm the script exits successfully and that its output demonstrates the control,
   exploit, and proof. An exit code alone is not evidence.
4. Read the transcript without the source. Ensure every request and actor is clear, both
   control cases are present, and the vulnerable line is unmistakable.
5. Run it through the configured intercepting proxy and confirm the requests are visible,
   actor sessions remain separate, and `X-PoC-Actor` is present when appropriate.
6. Search the artifact for local paths, private hosts, internal service names, job IDs,
   session-store URLs, unrelated credentials, and notes that rely on missing context.
7. Publish the verified transcript and place its absolute URL immediately after the report's
   Python command. Skip only for a client-side HTML/SVG entry whose result is visible.
8. Verify links from a clean environment and ensure report steps match the final artifact.
9. Confirm the test remained within authorization, used only owned test accounts, avoided
   real-user data, and left no unsafe state behind.

## Anti-example

This is not self-contained:

```bash
TOKEN="$(cat /tmp/private-workdir/token.txt | tr -d '\n\r')"
BASE=https://target.example.invalid
curl -s -H "Authorization: Bearer $TOKEN" "$BASE/api/private"
```

The token path exists only on the author's machine. On a triager's laptop the token is
empty, the request fails, and a real finding appears unreproducible.

Replace this pattern with one Python file that uses a permitted test-account login or a
clear TTY/environment-variable prompt, discovers required IDs, narrates the control and
exploit, and requires nothing beyond Python 3.

---

# House Integration — overrides the placeholders above

This section is binding for this installation and overrides any conflicting
instruction above it. The preceding public-skill guidance is adapted for the
current V4 safety and runtime contract; the source archive records the original.

## 1. Resolved placeholders

| Upstream placeholder | Resolved value in this installation |
|---|---|
| `https://poc.example.invalid` | **UNSET.** No publisher is configured. Do not substitute a real host. Keep `.invalid` so it stays non-resolving. A PoC URL cannot be produced until the user configures a publisher. |
| `/path/to/your/publish.py` | **UNSET.** See the publication gate below. |
| `/path/to/your/submit.py` | **UNSET.** Approved-finding report drafting is handled by `offsec-v4-reporting-agent`; it never publishes or submits externally. |
| `http://127.0.0.1:8080` | Default local intercepting proxy. Change only if the authorized test environment specifies another. |
| `X-PoC-Actor` | Keep as-is. It is a neutral example header. |

## 2. Artifact location

All PoC artifacts are written under the config root, not the home directory:

```
<config_root>/pentest/output/poc/<engagement_id>/<finding_id>/
    <finding_id>-<short-slug>.py       # or .html / .svg
    <finding_id>-<short-slug>.txt      # same-stem local-run transcript, server-side only
    transcript-proof.txt               # how the transcript was produced + exit code
```

`<config_root>` is the root containing `pentest/` and either `.opencode/agents/`
or `agents/`, as resolved by `pentest/framework/layout.py`. This is a proposed
artifact location, not a promise that the Dashboard lists or serves arbitrary files.

Follow `FRAMEWORK_RULES.md`: preserve redacted evidence references and do not
expose credentials in the response or report.

## 3. Publication gate (fail-closed)

**No PoC is published to any public host in this installation.**

- Artifact persistence requires an authorized output workflow. A managed worker
  with write/edit disabled returns proposed content and the intended path to Main;
  it must not bypass its tool permissions using shell writes or claim it saved a file.
- Publishing to any network location requires the user to approve that specific
  publication, in writing, naming the target and the host.
- Treat a hosted artifact as public even when its URL is unguessable.
- Never publish a transcript that contains a real credential, cookie, token,
  internal hostname, private service name, or another engagement's data.
- Report the actual local artifact path, if one was saved, to Main. The
  `offsec-v4-reporting-agent` only drafts approved reports; the user decides delivery.

If a stable public URL is genuinely required for triage, return
`status: "blocked"` with a `needs_publisher` note rather than improvising a host.

## 4. Preconditions before any PoC is built

The `poc-creation` skill assumes a confirmed finding. That is stricter than
what this pipeline guarantees, so verify all of the following first:

1. Main supplies a V4 finding ID and actual specialist evidence with verdict
   `confirmed`; check its state through `python -m pentest.framework.cli findings
   --engagement ENG`. V4 uses `framework-v4.db`, never the historical `findings.db`.
2. Preserve the recorded verification tier. `specialist_validated` and
   `replay_stable` do not establish independently proven impact; artifact authoring
   never changes finding status and never replaces the independent worker.
3. Use the supplied real evidence references, task context and observed impact.
   Missing proof is a limitation, not permission to invent an executable result.
4. The engagement status in `scope.json` is `authorized` or `authorized_limited`.

If any check fails, refuse. Do not build a "preliminary" PoC for an unconfirmed
claim, and never build a PoC for `<TARGET>` — it is `pending_authorization`.

## 5. Safety rules that tighten the upstream guidance

- Stdlib-only, self-contained, and proxy-optional requirements above are
  **mandatory**, not optional.
- Use only test accounts that exist for the authorized target. Never enumerate,
  read, or mutate another party's data, even to make the PoC look convincing.
- No bulk enumeration, no state-changing actions, no irreversible actions.
  Describe the potential impact in prose instead of demonstrating it at scale.
- Keep the smallest possible proof. If a single record demonstrates the bug,
  one record is the PoC.
- On cleanup, restore only data you created yourself.
- Before handing off, grep the finished artifact for: absolute local paths,
  `C:\Users\`, hostnames, internal service names, job ids, `127.0.0.1:8080`,
  unrelated credentials, and TODO markers. The "search the artifact" step in the
  Before shipping list is mandatory and its result is reported, not assumed.

## 6. Windows console note (`CONIN$` / `conin$`)

`/dev/tty` does not exist on Windows, so `open("/dev/tty")` raises `OSError` and every
interactive prompt (proxy URL, token, object ID) would fail on a Windows operator machine.
The `_open_terminal()` helper above already handles this: it tries `/dev/tty` first and then
falls back to the Windows console devices `CONIN$` / `conin$`, opened read-only. No separate
override snippet is needed.

- Signature, prompt text, stdout behaviour, the environment-variable fast path, and the
  `RuntimeError("No controlling terminal is available.")` contract are unchanged, so
  `ask_proxy()` and every call site keep working without modification.
- `CONIN$` / `conin$` is the Windows equivalent of `/dev/tty`; opening it read-only
  satisfies the open-read-only rule above.
- On a truly detached Windows process (no console), catch the `RuntimeError` at the call site
  or supply the value through the environment variable (`PROXY`, `TOKEN`, `VICTIM_ID`).
- Test both the real terminal path and the environment-variable path on the target OS before
  claiming the PoC works.
## Current V4 precedence
Use FRAMEWORK_RULES.md and the V4 task lease/independent verification contract (owned-canary for eligible access-auth/infra targets; weaker GET replay for any family with valid target/control receipts). Submit the real specialist record through the central CLI before completing its task; do not delay that durable handoff while constructing an optional artifact. Never bypass unsupported outcomes or write findings.db. External publication and report submission require the user's explicit authorization; this skill grants neither.
