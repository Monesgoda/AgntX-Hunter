---
name: offsec-enterprise-container
description: Docker container image and Kubernetes deployment security assessment.
---
# Container & Kubernetes Security
Review Docker and OCI images, service accounts, namespace RBAC, hostPath mounts, Docker socket access, capabilities, privileged pods, runtime patch levels, pod security admission, network policy and secret management. Prefer artifact-based configuration review (`kubectl auth can-i` under approved identity, image scanning, manifests). Do not modify production pods or test host escapes without explicit written approval and disposable environment. Correlate suspected IAM consequences with Cloud skill, credential-related findings with Access/Auth, and image provenance with Code Auditor.

## Containers and orchestration assessment
1. Establish platform, registry, runtime, Kubernetes cluster/namespace, service account, node pool and explicit tenant ownership.
2. Review Dockerfile/OCI images for outdated base layers, exposed secrets, risky entrypoints, writable system mounts and supply-chain provenance. Preserve digest and scanner signature.
3. Review pod specs: privileged flags, capabilities, hostPID/hostNetwork, unsafe hostPath, docker/container runtime sockets, seccomp/AppArmor/SELinux profiles, `readOnlyRootFilesystem`, dropped capabilities.
4. Review Kubernetes permissions and binding scopes for the approved identity. Use non-mutating effective-permission checks and compare expected duties to RBAC verbs; do not assume cluster-admin from a permissive role name alone.
5. Check pod-to-pod policies, admission controls, secrets encryption and audit logging. Define the namespace ownership boundary before deeper tests.
6. Identify likely lateral access hypotheses (e.g. projected tokens, shared volumes, overly permissive API roles) but use isolated fixtures to validate effects that might cross tenants or alter production.
7. Deliver affected resource/namespaces, manifest excerpts, RBAC result, identity, observed impact and security-control recommendation; route identity/cloud implications to matching specialists.
