/** Native OpenCode V2 plugin. Only Node built-ins; no provider/network calls.
 * Plugin.define is an identity helper in @opencode/plugin 2.3.2/2.4.1, so the
 * documented default { id, setup } definition needs no runtime dependency.
 * No tool/schema/permission pruning or changes to persisted session history.
 */
import { readFileSync, writeFileSync, mkdirSync, lstatSync, realpathSync } from 'node:fs';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const CONTINUATION_NOTE = 'Framework continuation: preserve engagement/scope reference, task IDs, live lease ownership, gateway receipts and evidence paths; use the central CLI. Read only relevant skill references. A finished task is not a verified vulnerability. Do not relaunch an ambiguous worker.';
const CAPTURE_TOOLS = new Set(['grep', 'glob', 'list']);

export default {
  id: 'offsec-context',
  async setup(ctx) {
    const root = findRoot(ctx.location?.directory) || findRoot(dirname(fileURLToPath(import.meta.url)));
    if (!root) return;
    const config = readConfig(root);
    if (config.enabled === false) return;
    const cap = Math.max(4000, Math.min(100000, Number(config.maxOutputChars) || 16000));
    const registrations = [];
    let active = true;
    let cleanupPromise;
    // OpenCode also scopes registrations to this plugin. Explicit, idempotent
    // disposal handles partial setup and makes retained callbacks inert on unload.
    const cleanup = () => {
      active = false;
      return cleanupPromise ??= (async () => {
        const results = await Promise.allSettled(registrations.splice(0).reverse().map((item) => item.dispose()));
        const errors = results.filter((item) => item.status === 'rejected').map((item) => item.reason);
        if (errors.length) throw new AggregateError(errors, 'offsec-context hook disposal failed');
      })();
    };
    try {
      registrations.push(await ctx.session.hook('compaction', (event) => {
        if (!active || !Array.isArray(event?.system)) return;
        if (!event.system.some((part) => part?.type === 'text' && typeof part.text === 'string' && part.text.includes(CONTINUATION_NOTE))) {
          event.system.push({ type: 'text', text: CONTINUATION_NOTE });
        }
      }));
      registrations.push(await ctx.tool.hook('execute.after', (event) => {
        // Exact allowlist: shell/CLI, gateway, proof and namespaced tools never
        // enter the capture path. Structured output and metadata stay intact.
        if (!active || config.captureLargeOutputs !== true || event?.status !== 'completed' || !CAPTURE_TOOLS.has(event.tool)) return;
        const result = event.result;
        if (!result || typeof result !== 'object') return;
        const content = captureContent(result.content, root, cap);
        if (content !== result.content) event.result = { ...result, content };
      }));
    } catch (error) {
      try { await cleanup(); } catch { /* Preserve the setup error; callbacks are already inert. */ }
      throw error;
    }
    return cleanup;
  },
};

function findRoot(start) {
  if (typeof start !== 'string' || !start) return;
  let root = resolve(start);
  while (true) {
    try {
      if (JSON.parse(readFileSync(join(root, 'RELEASE.json'), 'utf8'))?.package_id === 'opencode-offsec-merged') return root;
    } catch { /* Continue through ancestors, including the global-flat layout. */ }
    const parent = dirname(root);
    if (parent === root) return;
    root = parent;
  }
}

function readConfig(root) {
  try {
    const config = JSON.parse(readFileSync(join(root, 'token-saver.json'), 'utf8'));
    if (config && typeof config === 'object' && !Array.isArray(config)) return config;
  } catch { /* Missing or malformed settings use conservative defaults. */ }
  return {};
}

function captureContent(content, root, cap) {
  if (typeof content === 'string') return captureText(content, root, cap);
  if (!Array.isArray(content)) return content;
  // V2 also accepts Tool.Content[]: preserve part boundaries, file parts and
  // small text parts. Cap each large text part without flattening the result.
  let changed = false;
  const parts = content.map((part) => {
    if (part?.type !== 'text' || typeof part.text !== 'string') return part;
    const text = captureText(part.text, root, cap);
    if (text === part.text) return part;
    changed = true;
    return { ...part, text };
  });
  return changed ? parts : content;
}

function captureText(text, root, cap) {
  if (text.length <= cap) return text;
  try {
    const bytes = Buffer.from(text, 'utf8');
    // UTF-8 cannot round-trip lone UTF-16 surrogates. Keep such output whole.
    if (bytes.toString('utf8') !== text) return text;
    const digest = createHash('sha256').update(bytes).digest('hex');
    const path = join(captureDirectory(root), digest + '.txt');
    try {
      writeFileSync(path, bytes, { flag: 'wx', mode: 0o600 });
    } catch (error) {
      // A repeated output may reuse only an exact, ordinary-file capture.
      // Never overwrite a previous file or follow a capture-file symlink.
      if (error.code !== 'EEXIST' || !lstatSync(path).isFile() || !readFileSync(path).equals(bytes)) return text;
    }
    let preview = text.slice(0, cap);
    if (/[\uD800-\uDBFF]$/.test(preview)) preview = preview.slice(0, -1);
    return preview + '\n[Full output saved at ' + path + '; SHA-256 ' + digest + '. Read that file before drawing conclusions.]';
  } catch {
    // Availability or storage failure must retain the original tool output.
    return text;
  }
}

function captureDirectory(root) {
  let folder = realpathSync(root);
  for (const segment of ['pentest', 'output-v4', 'context-captures']) {
    folder = join(folder, segment);
    try { mkdirSync(folder, { mode: 0o700 }); }
    catch (error) { if (error.code !== 'EEXIST') throw error; }
    // Check each parent before descending: no junction/symlink may redirect
    // captures outside this installation, including during directory creation.
    if (!lstatSync(folder).isDirectory()) throw new Error('Unsafe context capture directory');
  }
  return folder;
}
